#!/usr/bin/env python
# coding: utf-8

# In[17]:


import requests
from bs4 import BeautifulSoup

# Define the URL of the webpage you want to scrape
url = "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api"

# Send a GET request to the URL
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find the elements you want to scrape
    # For example, let's say you want to extract all the links on the page
    links = soup.find_all('a')
    
    # Loop through the links and print their text and href attributes
    for link in links:
        link_text = link.text
        link_href = link.get('href')
        print(f"Text: {link_text}, URL: {link_href}")
else:
    print("Failed to retrieve the webpage")



# In[18]:


import requests
from bs4 import BeautifulSoup

# Define the URL of the webpage you want to scrape
url = "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api"

# Send a GET request to the URL
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find all anchor (a) tags with href attributes
    links = soup.find_all('a', href=True)
    
    # Loop through the links and print their href attributes
    for link in links:
        link_href = link['href']
        print(link_href)
else:
    print("Failed to retrieve the webpage")


# In[19]:


import requests
from bs4 import BeautifulSoup
import csv

# Define the URL of the webpage you want to scrape
url = "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api"

# Send a GET request to the URL
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find all anchor (a) tags with href attributes
    links = soup.find_all('a', href=True)
    
    # Create a list to store the links
    link_list = []
    
    # Loop through the links and add their href attributes to the list
    for link in links:
        link_href = link['href']
        link_list.append(link_href)
    
    # Define the CSV file name
    csv_filename = "nasa_earth_data_links.csv"
    
    # Write the links to a CSV file
    with open(csv_filename, 'w', newline='') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(['Link'])  # Write a header row
        for link in link_list:
            writer.writerow([link])
    
    print(f"Scraped links saved to {csv_filename}")
else:
    print("Failed to retrieve the webpage")


# In[20]:


import requests
from bs4 import BeautifulSoup
import pandas as pd

# Define the URL of the webpage you want to scrape
url = "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api"

# Send a GET request to the URL
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find all anchor (a) tags with href attributes
    links = soup.find_all('a', href=True)
    
    # Create a list to store the links
    link_list = []
    
    # Loop through the links and add their href attributes to the list
    for link in links:
        link_href = link['href']
        link_list.append(link_href)
    
    # Create a DataFrame from the list of links
    df = pd.DataFrame({'Link': link_list})
    
    # Print the first few rows of the DataFrame
    print(df.head())
else:
    print("Failed to retrieve the webpage")


# In[21]:


# Make a request to https://codedamn-classrooms.github.io/webscraper-python-codedamn-classroom-website/
# Store the result in 'res' variable
res = requests.get(
    'https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api ')
txt = res.text
status = res.status_code

print(txt, status)
# print the result


# In[22]:


from bs4 import BeautifulSoup

page = requests.get("https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api")
soup = BeautifulSoup(page.content, 'html.parser')
title = soup.title.text # gets you the text of the <title>(...)</title>


# In[23]:


import requests
from bs4 import BeautifulSoup

# Make a request to https://codedamn-classrooms.github.io/webscraper-python-codedamn-classroom-website/
page = requests.get(
    "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api")
soup = BeautifulSoup(page.content, 'html.parser')

# Extract title of page
page_title = soup.title.text

# print the result
print(page_title)


# In[24]:


import requests
from bs4 import BeautifulSoup

# Make a request
page = requests.get(
    "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api")
soup = BeautifulSoup(page.content, 'html.parser')

# Extract title of page
page_title = soup.title.text

# Extract body of page
page_body = soup.body

# Extract head of page
page_head = soup.head

# print the result
print(page_body, page_head)


# In[25]:


import requests
from bs4 import BeautifulSoup

# Make a request
page = requests.get(
    "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api")
soup = BeautifulSoup(page.content, 'html.parser')

# Extract title of page
page_title = soup.title

# Extract body of page
page_body = soup.body

# Extract head of page
page_head = soup.head

# print the result
print(page_title, page_head)


# In[26]:


import requests
from bs4 import BeautifulSoup

# Make a request
page = requests.get(
    "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api")
soup = BeautifulSoup(page.content, 'html.parser')

# Extract first <h1>(...)</h1> text
first_h1 = soup.select('h1')[0].text


# In[27]:


import requests
from bs4 import BeautifulSoup
# Make a request
page = requests.get(
    "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api")
soup = BeautifulSoup(page.content, 'html.parser')

# Create all_h1_tags as empty list
all_h1_tags = []

# Set all_h1_tags to all h1 tags of the soup
for element in soup.select('h1'):
    all_h1_tags.append(element.text)

# Create seventh_p_text and set it to 7th p element text of the page
seventh_p_text = soup.select('p')[6].text

print(all_h1_tags, seventh_p_text)


# In[28]:


info = {
   "title": 'Asus AsusPro Adv...   '.strip(),
   "review": '2 reviews\n\n\n'.strip()
}


# In[29]:


import requests
from bs4 import BeautifulSoup
# Make a request
page = requests.get(
    "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api")
soup = BeautifulSoup(page.content, 'html.parser')

# Create top_items as empty list
top_items = []

# Extract and store in top_items according to instructions on the left
products = soup.select('div.thumbnail')
for elem in products:
    title = elem.select('h4 > a.title')[0].text
    review_label = elem.select('div.ratings')[0].text
    info = {
        "title": title.strip(),
        "review": review_label.strip()
    }
    top_items.append(info)

print(top_items)


# In[30]:


import requests
from bs4 import BeautifulSoup
# Make a request
page = requests.get(
    "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api")
soup = BeautifulSoup(page.content, 'html.parser')

# Create top_items as empty list
image_data = []

# Extract and store in top_items according to instructions on the left
images = soup.select('img')
for image in images:
    src = image.get('src')
    alt = image.get('alt')
    image_data.append({"src": src, "alt": alt})

print(image_data)


# In[31]:


info = {
   "href": "<link here>",
   "text": "<link text here>"
}


# In[32]:


import requests
from bs4 import BeautifulSoup
# Make a request
page = requests.get(
    "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api")
soup = BeautifulSoup(page.content, 'html.parser')

# Create top_items as empty list
all_links = []

# Extract and store in top_items according to instructions on the left
links = soup.select('a')
for ahref in links:
    text = ahref.text
    text = text.strip() if text is not None else ''

    href = ahref.get('href')
    href = href.strip() if href is not None else ''
    all_links.append({"href": href, "text": text})

print(all_links)


# In[34]:


import requests
from bs4 import BeautifulSoup
import pandas as pd
import datetime

# Define the URL of the webpage you want to scrape
url = "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api"

# Send a GET request to the URL
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find all anchor (a) tags with href attributes
    links = soup.find_all('a', href=True)
    
    # Create a list to store the links
    link_list = []
    
    # Loop through the links and add their href attributes to the list
    for link in links:
        link_href = link['href']
        link_list.append(link_href)
    
    # Create a DataFrame from the list of links
    df = pd.DataFrame({'Link': link_list})
    
    # Define metadata
    metadata = {
        'Source URL': url,
        'Scraped Date': datetime.date.today().isoformat()
    }
    
    # Add metadata as additional columns
    for key, value in metadata.items():
        df[key] = value
    
    # Print the first few rows of the DataFrame with metadata
    print(df.head())
else:
    print("Failed to retrieve the webpage")


# In[35]:


import pandas as pd
import matplotlib.pyplot as plt

# Assuming you have a DataFrame 'df' with the scraped data
link_counts = df['Link'].value_counts()

# Create a bar chart
plt.figure(figsize=(12, 6))
link_counts.head(10).plot(kind='bar')
plt.title('Top 10 Most Common Links')
plt.xlabel('Link')
plt.ylabel('Frequency')
plt.xticks(rotation=45)
plt.show()


# In[40]:


import pandas as pd
import matplotlib.pyplot as plt

# Assuming you have a DataFrame 'df' with the scraped data
link_counts = df['Link'].value_counts()

# Create a bar chart
plt.figure(figsize=(12, 6))
link_counts.head(10).plot(kind='hist')
plt.title('Top 10 Most Common Links')
plt.xlabel('Link')
plt.ylabel('Frequency')
plt.xticks(rotation=45)
plt.show()


# In[39]:


import requests
from bs4 import BeautifulSoup
import matplotlib.pyplot as plt

# Define the URL of the webpage you want to scrape
url = "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api"

# Send a GET request to the URL
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find all anchor (a) tags with href attributes
    links = soup.find_all('a', href=True)
    
    # Create a list to store the lengths of link text
    link_text_lengths = [len(link.text) for link in links]
    
    # Create a histogram of link text lengths
    plt.hist(link_text_lengths, bins=20, edgecolor='k')
    plt.title('Histogram of Link Text Lengths')
    plt.xlabel('Text Length')
    plt.ylabel('Frequency')
    plt.show()
else:
    print("Failed to retrieve the webpage")


# In[41]:


import requests
from bs4 import BeautifulSoup
import matplotlib.pyplot as plt

# Define the URL of the webpage you want to scrape
url = "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api"

# Send a GET request to the URL
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find all anchor (a) tags with href attributes
    links = soup.find_all('a', href=True)
    
    # Create a list to store link categories (hypothetical)
    # You can modify this to categorize links based on your criteria
    link_categories = ['Category A', 'Category B', 'Category C']
    
    # Create a dictionary to store the count of links in each category
    category_counts = {category: 0 for category in link_categories}
    
    # Simulate categorizing links (you should replace this with your logic)
    for link in links:
        # Example: Categorize links based on the presence of specific keywords
        if 'keyword1' in link['href']:
            category_counts['Category A'] += 1
        elif 'keyword2' in link['href']:
            category_counts['Category B'] += 1
        else:
            category_counts['Category C'] += 1
    
    # Prepare data for the pie chart
    categories = list(category_counts.keys())
    counts = list(category_counts.values())
    
    # Create a pie chart
    plt.figure(figsize=(8, 8))
    plt.pie(counts, labels=categories, autopct='%1.1f%%', startangle=140)
    plt.title('Distribution of Link Categories')
    plt.show()
else:
    print("Failed to retrieve the webpage")


# In[44]:


import requests
from bs4 import BeautifulSoup
import seaborn as sns
import matplotlib.pyplot as plt

# Define the URL of the webpage you want to scrape
url = "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api"

# Send a GET request to the URL
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find all anchor (a) tags with href attributes
    links = soup.find_all('a', href=True)
    
    # Create a list to store the lengths of link text
    link_text_lengths = [len(link.text) for link in links]
    
    # Create a distribution plot (distplot)
    sns.set_style("whitegrid")
    plt.figure(figsize=(8, 6))
    sns.distplot(link_text_lengths, kde=False, bins=20)
    plt.title('Distribution of Link Text Lengths')
    plt.xlabel('Text Length')
    plt.ylabel('Frequency')
    plt.show()
else:
    print("Failed to retrieve the webpage")


# In[45]:


import requests
from bs4 import BeautifulSoup
import matplotlib.pyplot as plt
import pandas as pd

# Define the URL of the webpage you want to scrape
url = "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api"

# Send a GET request to the URL
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find all anchor (a) tags with href attributes
    links = soup.find_all('a', href=True)
    
    # Example: Create a DataFrame with hypothetical numerical data
    # Replace this with your actual data
    data = {
        'Date': pd.date_range(start='2023-01-01', periods=len(links)),  # Example dates
        'Value': range(len(links))  # Example numerical values
    }
    df = pd.DataFrame(data)
    
    # Create a line chart
    plt.figure(figsize=(10, 6))
    plt.plot(df['Date'], df['Value'], marker='o', linestyle='-')
    plt.title('Line Chart of Hypothetical Data')
    plt.xlabel('Date')
    plt.ylabel('Value')
    plt.grid(True)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
else:
    print("Failed to retrieve the webpage")


# In[46]:


import requests
from bs4 import BeautifulSoup
import matplotlib.pyplot as plt
import pandas as pd
import random

# Define the URL of the webpage you want to scrape
url = "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api"

# Send a GET request to the URL
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find all anchor (a) tags with href attributes
    links = soup.find_all('a', href=True)
    
    # Example: Create a DataFrame with random numerical data
    # Replace this with your actual data
    data = {
        'X_Value': [random.uniform(0, 10) for _ in links],  # Example X values
        'Y_Value': [random.uniform(0, 10) for _ in links]   # Example Y values
    }
    df = pd.DataFrame(data)
    
    # Create a scatter plot
    plt.figure(figsize=(8, 6))
    plt.scatter(df['X_Value'], df['Y_Value'], s=50, alpha=0.5)
    plt.title('Scatter Plot of Hypothetical Data')
    plt.xlabel('X Value')
    plt.ylabel('Y Value')
    plt.grid(True)
    plt.tight_layout()
    plt.show()
else:
    print("Failed to retrieve the webpage")


# In[47]:


import requests
from bs4 import BeautifulSoup
import matplotlib.pyplot as plt
import pandas as pd
import random

# Define the URL of the webpage you want to scrape
url = "https://www.earthdata.nasa.gov/engage/open-data-services-and-software/api"

# Send a GET request to the URL
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find all anchor (a) tags with href attributes
    links = soup.find_all('a', href=True)
    
    # Example: Create a DataFrame with random numerical data
    # Replace this with your actual data
    data = {
        'Value': [random.uniform(0, 10) for _ in links]  # Example numeric values
    }
    df = pd.DataFrame(data)
    
    # Create a box plot
    plt.figure(figsize=(6, 8))
    plt.boxplot(df['Value'], vert=False, widths=0.7)
    plt.title('Box Plot of Hypothetical Data')
    plt.xlabel('Value')
    plt.grid(True)
    plt.tight_layout()
    plt.show()
else:
    print("Failed to retrieve the webpage")


# In[ ]:




